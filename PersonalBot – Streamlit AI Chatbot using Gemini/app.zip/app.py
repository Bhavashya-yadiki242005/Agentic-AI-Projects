# app_personalbot.py
import streamlit as st
from google import genai
from dotenv import load_dotenv
import os

# Load API key from .env file
load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")

# Stop app if key is missing
if not API_KEY:
    st.error("Missing GEMINI_API_KEY in .env file. Please add it and restart the app.")
    st.stop()

# Initialize Gemini client
client = genai.Client(api_key=API_KEY)
MODEL_NAME = "models/gemini-2.5-flash"

# Configure Streamlit page
st.set_page_config(page_title="PersonalBot", layout="centered")
st.title("🤖 PersonalBot")
st.markdown("An intelligent assistant powered by **Gemini** and **Streamlit**.")

# Maintain chat history
if "history" not in st.session_state:
    st.session_state.history = []

# Function to generate response
def get_gemini_response(prompt):
    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=prompt
    )
    return response.text

# Display chat messages
for role, msg in st.session_state.history:
    if role == "user":
        st.markdown(f"**🧑 You:** {msg}")
    else:
        st.markdown(f"**🤖 PersonalBot:** {msg}")

# Input area for user query
user_input = st.text_input("Type your message here...")

if st.button("Send"):
    if user_input.strip():
        # Add user message
        st.session_state.history.append(("user", user_input))
        
        # Generate response
        with st.spinner("PersonalBot is thinking..."):
            try:
                reply = get_gemini_response(user_input)
            except Exception as e:
                reply = f"⚠️ Error: {e}"
        
        # Add bot reply
        st.session_state.history.append(("bot", reply))
        st.rerun() 
    else:
        st.warning("Please enter a message before sending.")
